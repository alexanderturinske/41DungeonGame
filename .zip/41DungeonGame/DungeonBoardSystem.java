/******************************************************************
 * DungeonBoardSystem.java
 * Alexander James Turinske
 *
 * This is the prgram for the dungeon board system.
 * *****************************************************************/

import java.util.Scanner;

public class DungeonBoardSystem
{
   private DungeonBoard game = new DungeonBoard();
   private Scanner stdIn = new Scanner(System.in);
   private String input;
   private int charLocation;
 
   //*****************************************************************

  public void move()
  {
    game.drawBoard(charLocation);
    System.out.println(game.getBoard());
    do
    {
      System.out.println("Move left (h), move right (l), or (q)uit? ");
      input = stdIn.next();
      if (input.equalsIgnoreCase("h") && !(charLocation == 0))
      {
        charLocation --;
        game.drawBoard(charLocation);
        System.out.println(game.getBoard());
      }
      else if (input.equalsIgnoreCase("l") && !(charLocation == 19))
      {
        charLocation ++;
        game.drawBoard(charLocation);
        System.out.println(game.getBoard());
      }
      else if ((input.equalsIgnoreCase("h") && charLocation == 0) || 
               (input.equalsIgnoreCase("l") && charLocation == 19))
      {
        System.out.println("You can't move out off the board!");
      }
      else if (input.equalsIgnoreCase("q"))
      {
        System.out.println("Thanks for playing!");
      }
      else
      {
        System.out.println("That is an invalid entry!");
        System.out.println(game.getBoard());
      }
    } while (!input.equalsIgnoreCase("q")); // end while loop
  } // end move method
} // end DungeonBoardSystem class 
