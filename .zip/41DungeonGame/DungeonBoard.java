/****************************************************************
* DungeonBoard.java
* Alexander James Turinske
*
* This draws a game board 
****************************************************************/

import java.util.Scanner;

public class DungeonBoard
{
  public final int WIDTH = 20;
  private String board;
  private String character = "C ";
  private int charLocation = 0;

  //**************************************************************

  public String getBoard()
  {
    return board;
  }  
 
  //****************************************************************

  public void drawBoard(int charLocation)
  {
    this.charLocation = charLocation;
    board = "";
    for (int i=0; i<WIDTH; i++)
    {
      if (i == charLocation)
      {
        board += character;
      }
      else
      {
        board += "* ";
      }
    }
  } // end drawBoard method
} // end DungeonBoard class
